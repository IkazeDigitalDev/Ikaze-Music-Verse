# Ikaze Music Club — reviewed website & E-Class setup

## Files
- `index.html` — responsive IMC public website, Google sign-in, group chat, private inbox, announcements, Ikaze AI starter and founder details.
- `courses.html` — published course catalogue, published lessons/resources and published E-Classes with Google sign-in enrolment.
- `admin.html` — protected admin console for courses, lessons, E-Classes, posts, members and private messages.
- `firebase.database.rules.json` — Realtime Database access rules.
- `firebase.storage.rules` — Storage rules for uploaded course/lesson resources.
- `assets/` — place the club logo at `assets/imc-logo.png`.

## Firebase setup (required for live operation)
1. Create a Firebase project and register a Web App in https://console.firebase.google.com/.
2. Copy the same Firebase Web App config into `FIREBASE_CONFIG` in `index.html`, `courses.html` and `admin.html`. Include the actual `storageBucket` value.
3. Enable Google under Authentication → Sign-in method. Add your deployed domain under Authentication → Settings → Authorized domains.
4. Create Realtime Database. Replace `YOUR_ADMIN_EMAIL@example.com` with the administrator's exact lowercase Google email in `index.html`, `admin.html`, `firebase.database.rules.json` and `firebase.storage.rules`.
5. Paste `firebase.database.rules.json` into Realtime Database → Rules and publish.
6. Enable Firebase Storage, paste `firebase.storage.rules` into Storage → Rules and publish.
7. Deploy the complete package to the same hosting root. Serve through HTTPS; Firebase Auth popups and Storage require an authorized web origin.

## E-Class workflow
1. Sign into `admin.html` with the Google account in the admin allowlist.
2. Open **E-Classes** and create a class: name, description, linked course (optional), teacher, start date/time, duration, recurring schedule, venue or online meeting URL, capacity and visibility.
3. Save as draft or publish. Published classes appear in `courses.html` under **Live & guided E-Classes**.
4. Students sign in with Google and click **Enrol in this class**. Enrolment is stored at `eClassMembers/{classId}/{uid}`. The capacity field is displayed as an enrolment guideline; this browser-only package does not guarantee hard capacity limits under simultaneous sign-ups. For strict limits, enforce enrolment through a trusted Cloud Function/backend.
5. In admin, use **Manage students** to view or remove enrolments. Hiding a class removes it from the public listing but retains enrolments.

## Courses and lesson materials
- Courses and lessons can be created, edited, published, hidden or deleted.
- Lessons support rich text notes plus multiple video, text, book/e-book, file, image, document/PDF, audio, external link and embed resources.
- Upload files through Firebase Storage in the lesson editor. Files are public by download URL, so do not upload private or sensitive material.
- Use HTTPS URLs for hosted resources.

## Member management and messaging
- The member list is populated when users sign in and join IMC Group.
- Admin can block/unblock, remove a club membership record, send a private message/notification and inspect/delete messages.
- Members can read their own private messages in the **My messages** inbox on the public website. Reading a message marks it read.
- Removing a club membership does not delete the person's Google/Firebase Authentication account. Deleting Authentication users requires Firebase Admin SDK on a trusted backend.

## Security and deployment notes
- The email allowlist in browser code controls dashboard visibility only. Realtime Database and Storage rules are the actual client-access enforcement. For production-grade role management, use Firebase custom claims and a trusted backend.
- Firebase Web App config is public by design; secure data with rules, App Check and server-side validation. Never place Admin SDK credentials or AI provider secret keys in HTML.
- The E-Class capacity transaction is client initiated and suitable for a basic club portal. For high-demand/paid enrolments, enforce capacity and payments in a trusted Cloud Function/backend.
- Firebase is not pre-connected: replace all placeholders and publish rules before live use.

## Translation and Ikaze AI
- Language selector includes English, Kinyarwanda, French, Swahili, Spanish and Portuguese UI strings. The Google Translate shortcut opens Google's website translation flow.
- Ikaze AI has a local knowledge starter. Configure a secure server endpoint in `index.html` for generative responses; do not expose API keys in the browser.

## IMC details
Founder: NIYIBIGIRA Theoneste · TTC Muhanga, Rwanda · Founded November 2026.
Slogan: “We Learn The Language Of Music And We Speak It Through The Piano.”
Contact: ikazedigital@gmail.com · WhatsApp +250 794 204 258.
Developer: https://ikaze-digital.vercel.app/
Founder portfolio: https://theonesteniyibigira6-hue.github.io/NIYIBIGIRA-/
